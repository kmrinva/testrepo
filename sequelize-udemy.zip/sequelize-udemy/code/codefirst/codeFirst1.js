// importing classes
const {Sequelize, Model, DataTypes} = require('sequelize');

// define database connection
const sequelize = new Sequelize("ormdemos", "root", "Allanon7", {
    host: 'localhost',
    dialect: 'mysql',
    pool: {
        min: 0,
        max: 5,
        idle: 10000
    },
    define: {
        timestamps:false
    }
});

class Department extends Model{};
//model class schema
Department.init({
    DeptNo: {type: DataTypes.INTEGER, primaryKey: true},
    DeptName: {type: DataTypes.STRING, allowNull: false},
    Location: {type: DataTypes.STRING, allowNull: false},
    Capacity: {type: DataTypes.INTEGER, allowNull: false},
    
},{sequelize, modelName:'Department'});

const departments = [
    {DeptNo:10, DeptName:'IT', Location:'Pune', Capacity:10 },
    {DeptNo:20, DeptName:'HR', Location:'Pune', Capacity:10 },
    {DeptNo:30, DeptName:'Sales', Location:'Pune', Capacity:300 },
    {DeptNo:40, DeptName:'Admin', Location:'Pune', Capacity:10 }
];

sequelize.sync({force:true})
.then(() => Department.bulkCreate(
    departments, {validate: true}
))
.then(() => {
    console.log('Data table Created with rows ${departments.length} ')
})
.catch((error) => {
    console.log('Error Occurred ${error}')
});
